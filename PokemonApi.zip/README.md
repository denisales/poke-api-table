# poke-api


## Dependencias do projeto

O projeto está utilizando o framework Vue.js, para executa-lo será preciso ter o Node instalado na máquina.

Após ter o Node.js intalado, será necessario rodar os comandos abaixo dentro da pasta do projeto.

## Para Instalar todas as dependencias do projeto 
```
npm install
```

### Para rodar e visualizar o projeto em modo de desenvolvimento com hot reload
```
npm run serve
```

### Para Compilar o projeto para produção
```
npm run build
```

### Usar o Lint para corrigir todos os arquivos
```
npm run lint
```
